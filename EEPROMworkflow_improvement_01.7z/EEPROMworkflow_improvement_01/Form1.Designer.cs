﻿
namespace EEPROMworkflow_improvement_01
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tp_SFF8472record_inDB = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dgv_SFF8472_info = new System.Windows.Forms.DataGridView();
            this.dgv_SFF8472_DDMI = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.dgv_SFF8472_A2 = new System.Windows.Forms.DataGridView();
            this.dgv_SFF8472_A0 = new System.Windows.Forms.DataGridView();
            this.tp_SFF8636record_inDB = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.cbo_model = new System.Windows.Forms.ComboBox();
            this.dgv_SFF8636_A0L = new System.Windows.Forms.DataGridView();
            this.dgv_SFF8636_P00 = new System.Windows.Forms.DataGridView();
            this.dgv_SFF8636_P03 = new System.Windows.Forms.DataGridView();
            this.dgv_SFF8636_info = new System.Windows.Forms.DataGridView();
            this.dgv_SFF8636_DDMI = new System.Windows.Forms.DataGridView();
            this.btn_SFF8636_saveA0L = new System.Windows.Forms.Button();
            this.btn_SFF8636_saveP00 = new System.Windows.Forms.Button();
            this.btn_SFF8636_saveP03 = new System.Windows.Forms.Button();
            this.tp_CMISrecord_inDB = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dgv_CMIS_A0L = new System.Windows.Forms.DataGridView();
            this.dgv_CMIS_P00 = new System.Windows.Forms.DataGridView();
            this.dgv_CMIS_P02 = new System.Windows.Forms.DataGridView();
            this.dgv_CMIS_P01 = new System.Windows.Forms.DataGridView();
            this.dgv_CMIS_info = new System.Windows.Forms.DataGridView();
            this.dgv_CMIS_DDMI = new System.Windows.Forms.DataGridView();
            this.btn_CMIS_saveA0L = new System.Windows.Forms.Button();
            this.btn_CMIS_saveP00 = new System.Windows.Forms.Button();
            this.btn_CMIS_saveP02 = new System.Windows.Forms.Button();
            this.btn_CMIS_saveP01 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tp_SFF8472record_inDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_DDMI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_A2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_A0)).BeginInit();
            this.tp_SFF8636record_inDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_A0L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_P00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_P03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_DDMI)).BeginInit();
            this.tp_CMISrecord_inDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_A0L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_P00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_P02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_P01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_DDMI)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tp_SFF8472record_inDB);
            this.tabControl1.Controls.Add(this.tp_SFF8636record_inDB);
            this.tabControl1.Controls.Add(this.tp_CMISrecord_inDB);
            this.tabControl1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(947, 810);
            this.tabControl1.TabIndex = 0;
            // 
            // tp_SFF8472record_inDB
            // 
            this.tp_SFF8472record_inDB.Controls.Add(this.button5);
            this.tp_SFF8472record_inDB.Controls.Add(this.button4);
            this.tp_SFF8472record_inDB.Controls.Add(this.dgv_SFF8472_info);
            this.tp_SFF8472record_inDB.Controls.Add(this.dgv_SFF8472_DDMI);
            this.tp_SFF8472record_inDB.Controls.Add(this.label3);
            this.tp_SFF8472record_inDB.Controls.Add(this.comboBox2);
            this.tp_SFF8472record_inDB.Controls.Add(this.dgv_SFF8472_A2);
            this.tp_SFF8472record_inDB.Controls.Add(this.dgv_SFF8472_A0);
            this.tp_SFF8472record_inDB.Location = new System.Drawing.Point(4, 28);
            this.tp_SFF8472record_inDB.Name = "tp_SFF8472record_inDB";
            this.tp_SFF8472record_inDB.Size = new System.Drawing.Size(939, 778);
            this.tp_SFF8472record_inDB.TabIndex = 2;
            this.tp_SFF8472record_inDB.Text = "SFF8472 record in the database";
            this.tp_SFF8472record_inDB.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(596, 690);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(69, 26);
            this.button5.TabIndex = 1232;
            this.button5.Text = "save A2";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(596, 145);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(69, 26);
            this.button4.TabIndex = 1232;
            this.button4.Text = "save A0";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dgv_SFF8472_info
            // 
            this.dgv_SFF8472_info.AllowUserToAddRows = false;
            this.dgv_SFF8472_info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8472_info.Location = new System.Drawing.Point(596, 177);
            this.dgv_SFF8472_info.Name = "dgv_SFF8472_info";
            this.dgv_SFF8472_info.ReadOnly = true;
            this.dgv_SFF8472_info.RowHeadersVisible = false;
            this.dgv_SFF8472_info.RowHeadersWidth = 51;
            this.dgv_SFF8472_info.Size = new System.Drawing.Size(234, 167);
            this.dgv_SFF8472_info.TabIndex = 1231;
            // 
            // dgv_SFF8472_DDMI
            // 
            this.dgv_SFF8472_DDMI.AllowUserToAddRows = false;
            this.dgv_SFF8472_DDMI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8472_DDMI.Location = new System.Drawing.Point(596, 369);
            this.dgv_SFF8472_DDMI.Name = "dgv_SFF8472_DDMI";
            this.dgv_SFF8472_DDMI.ReadOnly = true;
            this.dgv_SFF8472_DDMI.RowHeadersVisible = false;
            this.dgv_SFF8472_DDMI.RowHeadersWidth = 51;
            this.dgv_SFF8472_DDMI.Size = new System.Drawing.Size(239, 127);
            this.dgv_SFF8472_DDMI.TabIndex = 1230;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(596, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(276, 19);
            this.label3.TabIndex = 1229;
            this.label3.Text = "[FormericaOE].[dbo].[Standard_EEPROM]";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(596, 47);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(312, 27);
            this.comboBox2.TabIndex = 1228;
            // 
            // dgv_SFF8472_A2
            // 
            this.dgv_SFF8472_A2.AllowUserToAddRows = false;
            this.dgv_SFF8472_A2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8472_A2.Location = new System.Drawing.Point(17, 369);
            this.dgv_SFF8472_A2.Name = "dgv_SFF8472_A2";
            this.dgv_SFF8472_A2.ReadOnly = true;
            this.dgv_SFF8472_A2.RowHeadersVisible = false;
            this.dgv_SFF8472_A2.RowHeadersWidth = 51;
            this.dgv_SFF8472_A2.Size = new System.Drawing.Size(573, 347);
            this.dgv_SFF8472_A2.TabIndex = 17;
            // 
            // dgv_SFF8472_A0
            // 
            this.dgv_SFF8472_A0.AllowUserToAddRows = false;
            this.dgv_SFF8472_A0.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8472_A0.Location = new System.Drawing.Point(17, 16);
            this.dgv_SFF8472_A0.Name = "dgv_SFF8472_A0";
            this.dgv_SFF8472_A0.ReadOnly = true;
            this.dgv_SFF8472_A0.RowHeadersVisible = false;
            this.dgv_SFF8472_A0.RowHeadersWidth = 51;
            this.dgv_SFF8472_A0.Size = new System.Drawing.Size(573, 347);
            this.dgv_SFF8472_A0.TabIndex = 17;
            // 
            // tp_SFF8636record_inDB
            // 
            this.tp_SFF8636record_inDB.Controls.Add(this.label1);
            this.tp_SFF8636record_inDB.Controls.Add(this.cbo_model);
            this.tp_SFF8636record_inDB.Controls.Add(this.dgv_SFF8636_A0L);
            this.tp_SFF8636record_inDB.Controls.Add(this.dgv_SFF8636_P00);
            this.tp_SFF8636record_inDB.Controls.Add(this.dgv_SFF8636_P03);
            this.tp_SFF8636record_inDB.Controls.Add(this.dgv_SFF8636_info);
            this.tp_SFF8636record_inDB.Controls.Add(this.dgv_SFF8636_DDMI);
            this.tp_SFF8636record_inDB.Controls.Add(this.btn_SFF8636_saveA0L);
            this.tp_SFF8636record_inDB.Controls.Add(this.btn_SFF8636_saveP00);
            this.tp_SFF8636record_inDB.Controls.Add(this.btn_SFF8636_saveP03);
            this.tp_SFF8636record_inDB.Location = new System.Drawing.Point(4, 28);
            this.tp_SFF8636record_inDB.Name = "tp_SFF8636record_inDB";
            this.tp_SFF8636record_inDB.Padding = new System.Windows.Forms.Padding(3);
            this.tp_SFF8636record_inDB.Size = new System.Drawing.Size(939, 778);
            this.tp_SFF8636record_inDB.TabIndex = 0;
            this.tp_SFF8636record_inDB.Text = "SFF8636 record in the database";
            this.tp_SFF8636record_inDB.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(594, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(276, 19);
            this.label1.TabIndex = 1227;
            this.label1.Text = "[FormericaOE].[dbo].[Standard_EEPROM]";
            // 
            // cbo_model
            // 
            this.cbo_model.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_model.FormattingEnabled = true;
            this.cbo_model.Location = new System.Drawing.Point(594, 38);
            this.cbo_model.Name = "cbo_model";
            this.cbo_model.Size = new System.Drawing.Size(312, 27);
            this.cbo_model.TabIndex = 1226;
            // 
            // dgv_SFF8636_A0L
            // 
            this.dgv_SFF8636_A0L.AllowUserToAddRows = false;
            this.dgv_SFF8636_A0L.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8636_A0L.Location = new System.Drawing.Point(15, 16);
            this.dgv_SFF8636_A0L.Name = "dgv_SFF8636_A0L";
            this.dgv_SFF8636_A0L.ReadOnly = true;
            this.dgv_SFF8636_A0L.RowHeadersVisible = false;
            this.dgv_SFF8636_A0L.RowHeadersWidth = 51;
            this.dgv_SFF8636_A0L.Size = new System.Drawing.Size(573, 186);
            this.dgv_SFF8636_A0L.TabIndex = 1201;
            // 
            // dgv_SFF8636_P00
            // 
            this.dgv_SFF8636_P00.AllowUserToAddRows = false;
            this.dgv_SFF8636_P00.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8636_P00.Location = new System.Drawing.Point(15, 208);
            this.dgv_SFF8636_P00.Name = "dgv_SFF8636_P00";
            this.dgv_SFF8636_P00.ReadOnly = true;
            this.dgv_SFF8636_P00.RowHeadersVisible = false;
            this.dgv_SFF8636_P00.RowHeadersWidth = 51;
            this.dgv_SFF8636_P00.Size = new System.Drawing.Size(573, 186);
            this.dgv_SFF8636_P00.TabIndex = 1201;
            // 
            // dgv_SFF8636_P03
            // 
            this.dgv_SFF8636_P03.AllowUserToAddRows = false;
            this.dgv_SFF8636_P03.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8636_P03.Location = new System.Drawing.Point(15, 400);
            this.dgv_SFF8636_P03.Name = "dgv_SFF8636_P03";
            this.dgv_SFF8636_P03.ReadOnly = true;
            this.dgv_SFF8636_P03.RowHeadersVisible = false;
            this.dgv_SFF8636_P03.RowHeadersWidth = 51;
            this.dgv_SFF8636_P03.Size = new System.Drawing.Size(573, 186);
            this.dgv_SFF8636_P03.TabIndex = 1202;
            // 
            // dgv_SFF8636_info
            // 
            this.dgv_SFF8636_info.AllowUserToAddRows = false;
            this.dgv_SFF8636_info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8636_info.Location = new System.Drawing.Point(594, 208);
            this.dgv_SFF8636_info.Name = "dgv_SFF8636_info";
            this.dgv_SFF8636_info.ReadOnly = true;
            this.dgv_SFF8636_info.RowHeadersVisible = false;
            this.dgv_SFF8636_info.RowHeadersWidth = 51;
            this.dgv_SFF8636_info.Size = new System.Drawing.Size(234, 167);
            this.dgv_SFF8636_info.TabIndex = 1224;
            // 
            // dgv_SFF8636_DDMI
            // 
            this.dgv_SFF8636_DDMI.AllowUserToAddRows = false;
            this.dgv_SFF8636_DDMI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SFF8636_DDMI.Location = new System.Drawing.Point(594, 400);
            this.dgv_SFF8636_DDMI.Name = "dgv_SFF8636_DDMI";
            this.dgv_SFF8636_DDMI.ReadOnly = true;
            this.dgv_SFF8636_DDMI.RowHeadersVisible = false;
            this.dgv_SFF8636_DDMI.RowHeadersWidth = 51;
            this.dgv_SFF8636_DDMI.Size = new System.Drawing.Size(239, 127);
            this.dgv_SFF8636_DDMI.TabIndex = 1225;
            // 
            // btn_SFF8636_saveA0L
            // 
            this.btn_SFF8636_saveA0L.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SFF8636_saveA0L.Location = new System.Drawing.Point(594, 176);
            this.btn_SFF8636_saveA0L.Name = "btn_SFF8636_saveA0L";
            this.btn_SFF8636_saveA0L.Size = new System.Drawing.Size(69, 26);
            this.btn_SFF8636_saveA0L.TabIndex = 1210;
            this.btn_SFF8636_saveA0L.Text = "save A0L";
            this.btn_SFF8636_saveA0L.UseVisualStyleBackColor = true;
            // 
            // btn_SFF8636_saveP00
            // 
            this.btn_SFF8636_saveP00.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SFF8636_saveP00.Location = new System.Drawing.Point(835, 208);
            this.btn_SFF8636_saveP00.Name = "btn_SFF8636_saveP00";
            this.btn_SFF8636_saveP00.Size = new System.Drawing.Size(69, 26);
            this.btn_SFF8636_saveP00.TabIndex = 1210;
            this.btn_SFF8636_saveP00.Text = "save P00";
            this.btn_SFF8636_saveP00.UseVisualStyleBackColor = true;
            // 
            // btn_SFF8636_saveP03
            // 
            this.btn_SFF8636_saveP03.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SFF8636_saveP03.Location = new System.Drawing.Point(800, 400);
            this.btn_SFF8636_saveP03.Name = "btn_SFF8636_saveP03";
            this.btn_SFF8636_saveP03.Size = new System.Drawing.Size(69, 26);
            this.btn_SFF8636_saveP03.TabIndex = 1215;
            this.btn_SFF8636_saveP03.Text = "save P03";
            this.btn_SFF8636_saveP03.UseVisualStyleBackColor = true;
            // 
            // tp_CMISrecord_inDB
            // 
            this.tp_CMISrecord_inDB.Controls.Add(this.label2);
            this.tp_CMISrecord_inDB.Controls.Add(this.comboBox1);
            this.tp_CMISrecord_inDB.Controls.Add(this.dgv_CMIS_A0L);
            this.tp_CMISrecord_inDB.Controls.Add(this.dgv_CMIS_P00);
            this.tp_CMISrecord_inDB.Controls.Add(this.dgv_CMIS_P02);
            this.tp_CMISrecord_inDB.Controls.Add(this.dgv_CMIS_P01);
            this.tp_CMISrecord_inDB.Controls.Add(this.dgv_CMIS_info);
            this.tp_CMISrecord_inDB.Controls.Add(this.dgv_CMIS_DDMI);
            this.tp_CMISrecord_inDB.Controls.Add(this.btn_CMIS_saveA0L);
            this.tp_CMISrecord_inDB.Controls.Add(this.btn_CMIS_saveP00);
            this.tp_CMISrecord_inDB.Controls.Add(this.btn_CMIS_saveP02);
            this.tp_CMISrecord_inDB.Controls.Add(this.btn_CMIS_saveP01);
            this.tp_CMISrecord_inDB.Location = new System.Drawing.Point(4, 28);
            this.tp_CMISrecord_inDB.Name = "tp_CMISrecord_inDB";
            this.tp_CMISrecord_inDB.Padding = new System.Windows.Forms.Padding(3);
            this.tp_CMISrecord_inDB.Size = new System.Drawing.Size(939, 778);
            this.tp_CMISrecord_inDB.TabIndex = 1;
            this.tp_CMISrecord_inDB.Text = "CMIS record in the database";
            this.tp_CMISrecord_inDB.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(588, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(276, 19);
            this.label2.TabIndex = 1237;
            this.label2.Text = "[FormericaOE].[dbo].[Standard_EEPROM]";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(588, 30);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(312, 27);
            this.comboBox1.TabIndex = 1236;
            // 
            // dgv_CMIS_A0L
            // 
            this.dgv_CMIS_A0L.AllowUserToAddRows = false;
            this.dgv_CMIS_A0L.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CMIS_A0L.Location = new System.Drawing.Point(9, 8);
            this.dgv_CMIS_A0L.Name = "dgv_CMIS_A0L";
            this.dgv_CMIS_A0L.ReadOnly = true;
            this.dgv_CMIS_A0L.RowHeadersVisible = false;
            this.dgv_CMIS_A0L.RowHeadersWidth = 51;
            this.dgv_CMIS_A0L.Size = new System.Drawing.Size(573, 186);
            this.dgv_CMIS_A0L.TabIndex = 1228;
            // 
            // dgv_CMIS_P00
            // 
            this.dgv_CMIS_P00.AllowUserToAddRows = false;
            this.dgv_CMIS_P00.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CMIS_P00.Location = new System.Drawing.Point(9, 200);
            this.dgv_CMIS_P00.Name = "dgv_CMIS_P00";
            this.dgv_CMIS_P00.ReadOnly = true;
            this.dgv_CMIS_P00.RowHeadersVisible = false;
            this.dgv_CMIS_P00.RowHeadersWidth = 51;
            this.dgv_CMIS_P00.Size = new System.Drawing.Size(573, 186);
            this.dgv_CMIS_P00.TabIndex = 1229;
            // 
            // dgv_CMIS_P02
            // 
            this.dgv_CMIS_P02.AllowUserToAddRows = false;
            this.dgv_CMIS_P02.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CMIS_P02.Location = new System.Drawing.Point(9, 584);
            this.dgv_CMIS_P02.Name = "dgv_CMIS_P02";
            this.dgv_CMIS_P02.ReadOnly = true;
            this.dgv_CMIS_P02.RowHeadersVisible = false;
            this.dgv_CMIS_P02.RowHeadersWidth = 51;
            this.dgv_CMIS_P02.Size = new System.Drawing.Size(573, 186);
            this.dgv_CMIS_P02.TabIndex = 1230;
            // 
            // dgv_CMIS_P01
            // 
            this.dgv_CMIS_P01.AllowUserToAddRows = false;
            this.dgv_CMIS_P01.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CMIS_P01.Location = new System.Drawing.Point(9, 392);
            this.dgv_CMIS_P01.Name = "dgv_CMIS_P01";
            this.dgv_CMIS_P01.ReadOnly = true;
            this.dgv_CMIS_P01.RowHeadersVisible = false;
            this.dgv_CMIS_P01.RowHeadersWidth = 51;
            this.dgv_CMIS_P01.Size = new System.Drawing.Size(573, 186);
            this.dgv_CMIS_P01.TabIndex = 1230;
            // 
            // dgv_CMIS_info
            // 
            this.dgv_CMIS_info.AllowUserToAddRows = false;
            this.dgv_CMIS_info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CMIS_info.Location = new System.Drawing.Point(588, 200);
            this.dgv_CMIS_info.Name = "dgv_CMIS_info";
            this.dgv_CMIS_info.ReadOnly = true;
            this.dgv_CMIS_info.RowHeadersVisible = false;
            this.dgv_CMIS_info.RowHeadersWidth = 51;
            this.dgv_CMIS_info.Size = new System.Drawing.Size(234, 167);
            this.dgv_CMIS_info.TabIndex = 1234;
            // 
            // dgv_CMIS_DDMI
            // 
            this.dgv_CMIS_DDMI.AllowUserToAddRows = false;
            this.dgv_CMIS_DDMI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CMIS_DDMI.Location = new System.Drawing.Point(588, 584);
            this.dgv_CMIS_DDMI.Name = "dgv_CMIS_DDMI";
            this.dgv_CMIS_DDMI.ReadOnly = true;
            this.dgv_CMIS_DDMI.RowHeadersVisible = false;
            this.dgv_CMIS_DDMI.RowHeadersWidth = 51;
            this.dgv_CMIS_DDMI.Size = new System.Drawing.Size(239, 127);
            this.dgv_CMIS_DDMI.TabIndex = 1235;
            // 
            // btn_CMIS_saveA0L
            // 
            this.btn_CMIS_saveA0L.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CMIS_saveA0L.Location = new System.Drawing.Point(588, 168);
            this.btn_CMIS_saveA0L.Name = "btn_CMIS_saveA0L";
            this.btn_CMIS_saveA0L.Size = new System.Drawing.Size(69, 26);
            this.btn_CMIS_saveA0L.TabIndex = 1231;
            this.btn_CMIS_saveA0L.Text = "save A0L";
            this.btn_CMIS_saveA0L.UseVisualStyleBackColor = true;
            // 
            // btn_CMIS_saveP00
            // 
            this.btn_CMIS_saveP00.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CMIS_saveP00.Location = new System.Drawing.Point(831, 200);
            this.btn_CMIS_saveP00.Name = "btn_CMIS_saveP00";
            this.btn_CMIS_saveP00.Size = new System.Drawing.Size(69, 26);
            this.btn_CMIS_saveP00.TabIndex = 1232;
            this.btn_CMIS_saveP00.Text = "save P00";
            this.btn_CMIS_saveP00.UseVisualStyleBackColor = true;
            // 
            // btn_CMIS_saveP02
            // 
            this.btn_CMIS_saveP02.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CMIS_saveP02.Location = new System.Drawing.Point(794, 584);
            this.btn_CMIS_saveP02.Name = "btn_CMIS_saveP02";
            this.btn_CMIS_saveP02.Size = new System.Drawing.Size(69, 26);
            this.btn_CMIS_saveP02.TabIndex = 1233;
            this.btn_CMIS_saveP02.Text = "save P02";
            this.btn_CMIS_saveP02.UseVisualStyleBackColor = true;
            // 
            // btn_CMIS_saveP01
            // 
            this.btn_CMIS_saveP01.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CMIS_saveP01.Location = new System.Drawing.Point(588, 392);
            this.btn_CMIS_saveP01.Name = "btn_CMIS_saveP01";
            this.btn_CMIS_saveP01.Size = new System.Drawing.Size(69, 26);
            this.btn_CMIS_saveP01.TabIndex = 1233;
            this.btn_CMIS_saveP01.Text = "save P01";
            this.btn_CMIS_saveP01.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 825);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tp_SFF8472record_inDB.ResumeLayout(false);
            this.tp_SFF8472record_inDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_DDMI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_A2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8472_A0)).EndInit();
            this.tp_SFF8636record_inDB.ResumeLayout(false);
            this.tp_SFF8636record_inDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_A0L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_P00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_P03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SFF8636_DDMI)).EndInit();
            this.tp_CMISrecord_inDB.ResumeLayout(false);
            this.tp_CMISrecord_inDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_A0L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_P00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_P02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_P01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CMIS_DDMI)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tp_SFF8636record_inDB;
        private System.Windows.Forms.TabPage tp_CMISrecord_inDB;
        private System.Windows.Forms.TabPage tp_SFF8472record_inDB;
        private System.Windows.Forms.DataGridView dgv_SFF8472_info;
        private System.Windows.Forms.DataGridView dgv_SFF8472_DDMI;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.DataGridView dgv_SFF8472_A2;
        private System.Windows.Forms.DataGridView dgv_SFF8472_A0;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbo_model;
        private System.Windows.Forms.DataGridView dgv_SFF8636_A0L;
        private System.Windows.Forms.DataGridView dgv_SFF8636_P00;
        private System.Windows.Forms.DataGridView dgv_SFF8636_P03;
        private System.Windows.Forms.DataGridView dgv_SFF8636_info;
        private System.Windows.Forms.DataGridView dgv_SFF8636_DDMI;
        private System.Windows.Forms.Button btn_SFF8636_saveA0L;
        private System.Windows.Forms.Button btn_SFF8636_saveP00;
        private System.Windows.Forms.Button btn_SFF8636_saveP03;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dgv_CMIS_A0L;
        private System.Windows.Forms.DataGridView dgv_CMIS_P00;
        private System.Windows.Forms.DataGridView dgv_CMIS_P02;
        private System.Windows.Forms.DataGridView dgv_CMIS_P01;
        private System.Windows.Forms.DataGridView dgv_CMIS_info;
        private System.Windows.Forms.DataGridView dgv_CMIS_DDMI;
        private System.Windows.Forms.Button btn_CMIS_saveA0L;
        private System.Windows.Forms.Button btn_CMIS_saveP00;
        private System.Windows.Forms.Button btn_CMIS_saveP01;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_CMIS_saveP02;
    }
}

